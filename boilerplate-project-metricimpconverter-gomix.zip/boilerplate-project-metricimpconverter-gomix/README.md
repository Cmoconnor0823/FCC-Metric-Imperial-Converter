**FreeCodeCamp**- Information Security and Quality Assurance
------
[![Run on Repl.it](https://repl.it/badge/github/freeCodeCamp/boilerplate-project-metricimpconverter)](https://repl.it/github/freeCodeCamp/boilerplate-project-metricimpconverter)
1) SET NODE_ENV to `test` without quotes
2) Most logic will need done in `controllers/convertHandler.js` but do complete `routes/api.js`
3) You will add any security features to `server.js`
4) You will create all of the functional/unit tests in `tests/2_functional-tests.js` and `tests/1_unit-tests.js`


